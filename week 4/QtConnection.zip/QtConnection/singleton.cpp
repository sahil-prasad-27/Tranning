#include <iostream>

class Singleton {
private:
    // Private constructor so no one can create directly
    Singleton() {
        std::cout << "Singleton instance created!\n";
    }

    // Private copy constructor and assignment to prevent copies
    Singleton(const Singleton&) = delete;
    Singleton& operator=(const Singleton&) = delete;

public:
    // Public pointer to hold the single instance (declared globally outside)
    friend Singleton* getSingletonInstance();
    
    void showMessage() {
        std::cout << "Hello from Singleton!\n";
    }
};

// Global pointer to store the singleton instance
Singleton* singletonInstance = nullptr;

Singleton* getSingletonInstance() {
    if (singletonInstance == nullptr) {
        singletonInstance = new Singleton();
    }
    return singletonInstance;
}

int main() {
    Singleton* s1 = getSingletonInstance();
    s1->showMessage();

    Singleton* s2 = getSingletonInstance();
    s2->showMessage();

    if (s1 == s2) {
        std::cout << "Both point to the same instance!\n";
    }

    return 0;
}
